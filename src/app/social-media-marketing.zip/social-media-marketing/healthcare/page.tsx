import Image from "next/image";

export default function HealthcarePage() {
  const images = [
    
        "/upload/social-media-marketing/healthcare/heathcare1.webp",
        "/upload/social-media-marketing/healthcare/healthcare2.webp",
        "/upload/social-media-marketing/healthcare/healthcare3.webp",
        "/upload/social-media-marketing/healthcare/healthcare4.webp",
        "/upload/social-media-marketing/healthcare/healthcare5.webp",
        "/upload/social-media-marketing/healthcare/healthcare6.webp",
         "/upload/social-media-marketing/healthcare/healthcare7.webp",
        "/upload/social-media-marketing/healthcare/healthcare8.webp",
        "/upload/social-media-marketing/healthcare/healthcare9.webp",
        "/upload/social-media-marketing/healthcare/healthcare10.webp",
        "/upload/social-media-marketing/healthcare/healthcare11.webp",
        "/upload/social-media-marketing/healthcare/healthcare12.webp",
        "/upload/social-media-marketing/healthcare/healthcare13.webp",
        "/upload/social-media-marketing/healthcare/healthcare14.webp",
  ];
  return (
    <section className="container mx-auto py-12 px-4 text-center mt-20">
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {images.map((src, index) => (
          <div key={index} className="rounded-xl overflow-hidden shadow-lg dark:border-gray-50 rounded-md hover:-translate-y-4 hover:shadow-[0px_5px_10px_rgba(0,0,0,0.07),0px_-5px_10px_rgba(0,0,0,0.07)] dark:shadow-[0px_3px_6px_rgba(255,255,255,0.15),0px_-3px_6px_rgba(255,255,255,0.15)] transform transition-transform duration-300 cursor-pointer">
            <Image
              src={src}
              alt="image not found"
              width={400}
              height={300}
              className="object-cover w-full h-full"
            />
          </div>
        ))}
      </div>
    </section>
  );
}
