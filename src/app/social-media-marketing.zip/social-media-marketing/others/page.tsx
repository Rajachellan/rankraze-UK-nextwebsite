import Image from "next/image";

export default function OtherPage() {
  const images = [
    
        "/upload/social-media-marketing/others/others1.webp" ,
        "/upload/social-media-marketing/others/others2.webp",
        "/upload/social-media-marketing/others/others3.webp",
        "/upload/social-media-marketing/others/others4.webp",
        "/upload/social-media-marketing/others/others5.webp",
        "/upload/social-media-marketing/others/others6.webp",
        "/upload/social-media-marketing/others/others7.webp",
        "/upload/social-media-marketing/others/others8.webp",
        "/upload/social-media-marketing/others/others9.webp",
        "/upload/social-media-marketing/others/others10.webp",
        "/upload/social-media-marketing/others/others11.GIF",
        "/upload/social-media-marketing/others/others12.webp",
        "/upload/social-media-marketing/others/others13.webp",
        "/upload/social-media-marketing/others/others14.webp",
        "/upload/social-media-marketing/others/others15.webp",
        "/upload/social-media-marketing/others/others16.webp",
        "/upload/social-media-marketing/others/others17.webp",
        "/upload/social-media-marketing/others/others18.webp",
        "/upload/social-media-marketing/others/others19.webp",
        "/upload/social-media-marketing/others/others20.webp",
        "/upload/social-media-marketing/others/others21.webp",
        "/upload/social-media-marketing/others/others22.webp",
        "/upload/social-media-marketing/others/others23.webp",

        

  ];
  return (
    <section className="container mx-auto py-12 px-4 text-center mt-20">
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {images.map((src, index) => (
          <div key={index} className="rounded-xl overflow-hidden shadow-lg dark:border-gray-50 rounded-md hover:-translate-y-4 hover:shadow-[0px_5px_10px_rgba(0,0,0,0.07),0px_-5px_10px_rgba(0,0,0,0.07)] dark:shadow-[0px_3px_6px_rgba(255,255,255,0.15),0px_-3px_6px_rgba(255,255,255,0.15)] transform transition-transform duration-300 cursor-pointer">
            <Image
              src={src}
              alt="image not found"
              width={400}
              height={300}
              className="object-cover w-full h-full"
            />
          </div>
        ))}
      </div>
    </section>
  );
}
