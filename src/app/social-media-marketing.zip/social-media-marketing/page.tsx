import Link from "next/link"; 
export default function PortfolioPage() {
  return (
    <>
      {/* portfolio section */}
      <section className="container mx-auto py-12 px-4 text-center">
        <div className="w-full flex items-center justify-center relative before:content-[''] before:absolute before:w-full before:h-full before:bg-linear-to-b before:from-[#DAF8F1] before:to-transparent dark:before:invert before:rounded-t-4xl before:-z-10">
          <div className="w-full flex flex-col items-center justify-center gap-2.5 md:gap-3.t xl:gap-4 py-8 md:py-12 xl:py-20 2xl:py-24 max-w-2xl">
            <h1 className="text-2xl xl:text-4xl capitalize font-bold text-gray-800 dark:text-gray-100">
              Social Media Marketing Portfolio
            </h1>
          </div>
        </div>
      </section>
      <div className="container mx-auto text-center ">
        <div className="flex flex-wrap justify-center gap-4 mb-8">
          <Link
            href="/social-media-marketing/education"
            className="text-white bg-[var(--primary-green)] px-5 py-3 rounded md:rounded-lg w-40 block hover:bg-white"
          >
            Education
          </Link>
          <Link href="/social-media-marketing/healthcare" className="text-white bg-[var(--primary-green)] px-5 py-3 rounded md:rounded-lg w-40 block  hover:bg-white">
            Healthcare
          </Link>
          <Link href="/social-media-marketing/food" className="text-white bg-[var(--primary-green)] px-5 py-3 rounded md:rounded-lg w-40 block hover:bg-white">
            Food
          </Link>
          <Link href="/social-media-marketing/beauty" className="text-white bg-[var(--primary-green)] px-5 py-3 rounded md:rounded-lg w-40 block hover:bg-white">
            Beauty
          </Link>
          <Link href="/social-media-marketing/gardening" className="text-white bg-[var(--primary-green)] px-5 py-3 rounded md:rounded-lg w-40 block hover:bg-white">
            Gardening
          </Link>
          <Link href="/social-media-marketing/realestate" className="text-white bg-[var(--primary-green)] px-5 py-3 rounded md:rounded-lg w-40 block hover:bg-white">
            Real Estate
          </Link>
          <Link href="/social-media-marketing/clothing" className="text-white bg-[var(--primary-green)] px-5 py-3 rounded md:rounded-lg w-40 block hover:bg-white">
            Clothing
          </Link>
          <Link href="/social-media-marketing/logistics" className="text-white bg-[var(--primary-green)] px-5 py-3 rounded md:rounded-lg w-40 block hover:bg-white">
            Logistics
          </Link>
          <Link href="/social-media-marketing/it" className="text-white bg-[var(--primary-green)] px-5 py-3 rounded md:rounded-lg w-40 block hover:bg-white">
            IT
          </Link>
          <Link href="/social-media-marketing/ecommerce" className="text-white bg-[var(--primary-green)] px-5 py-3 rounded md:rounded-lg w-40 block hover:bg-white">
            Ecommerce
          </Link>
          <Link href="/social-media-marketing/bilingual" className="text-white bg-[var(--primary-green)] px-5 py-3 rounded md:rounded-lg w-40 block hover:bg-white">
            Bilingual
          </Link>
          <Link href="/social-media-marketing/branding" className="text-white bg-[var(--primary-green)] px-5 py-3 rounded md:rounded-lg w-40 block hover:bg-white">
            Branding
          </Link>
          <Link href="/social-media-marketing/others" className="text-white bg-[var(--primary-green)] px-5 py-3 rounded md:rounded-lg w-40 block hover:bg-white">
            Others
          </Link>
        </div>
      </div>
    </>
  );
}





