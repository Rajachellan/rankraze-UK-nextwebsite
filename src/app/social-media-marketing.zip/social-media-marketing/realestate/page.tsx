import Image from "next/image";

export default function RealestatePage() {
  const images = [
        "/upload/social-media-marketing/realestate/realestate1.webp",
        "/upload/social-media-marketing/realestate/realestate2.webp",
        "/upload/social-media-marketing/realestate/realestate3.webp",
        "/upload/social-media-marketing/realestate/realestate4.webp",
        "/upload/social-media-marketing/realestate/realestate5.webp",
        "/upload/social-media-marketing/realestate/realestate6.webp",
        "/upload/social-media-marketing/realestate/realestate7.webp",
        "/upload/social-media-marketing/realestate/realestate8.webp",
          "/upload/social-media-marketing/realestate/realestate9.webp",
        "/upload/social-media-marketing/realestate/realestate10.webp",
        "/upload/social-media-marketing/realestate/realestate11.webp",
          "/upload/social-media-marketing/realestate/realestate12.webp",
        "/upload/social-media-marketing/realestate/realestate13.webp",
        "/upload/social-media-marketing/realestate/realestate14.webp",
        "/upload/social-media-marketing/realestate/realestate15.webp",


  ];
  return (
    <section className="container mx-auto py-12 px-4 text-center mt-20">
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {images.map((src, index) => (
          <div key={index} className="rounded-xl overflow-hidden  dark:border-gray-50 rounded-md hover:-translate-y-4 hover:shadow-[0px_5px_10px_rgba(0,0,0,0.07),0px_-5px_10px_rgba(0,0,0,0.07)] dark:shadow-[0px_3px_6px_rgba(255,255,255,0.15),0px_-3px_6px_rgba(255,255,255,0.15)] transform transition-transform duration-300 cursor-pointer">
            <Image
              src={src}
              alt="image not found"
              width={400}
              height={300}
              className="object-cover w-full h-full"
            />
          </div>
        ))}
      </div>
    </section>
  );
}
